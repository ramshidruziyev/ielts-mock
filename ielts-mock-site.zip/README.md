
IELTS MOCK WEBSITE

Run:
npm install
node server.js

Frontend: Netlify/Vercel
Backend: Render/Railway

Admin activates premium via ID.

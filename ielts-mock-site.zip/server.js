
import express from "express";
import fs from "fs";
const app=express();
app.use(express.json());
app.use(express.static("public"));

const load=()=>JSON.parse(fs.readFileSync("data/users.json"));
const save=d=>fs.writeFileSync("data/users.json",JSON.stringify(d,null,2));

app.get("/user/status",(req,res)=>{
 const u=load()[req.query.id]||{status:"free"};
 res.json(u);
});

app.post("/admin/activate",(req,res)=>{
 const u=load();
 u[req.body.id]={status:"premium",expire:new Date(Date.now()+30*86400000)};
 save(u); res.json({ok:true});
});

app.listen(3000);
